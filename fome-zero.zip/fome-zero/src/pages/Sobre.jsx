import { useEffect, useState } from "react";
import AppChrome from "@/components/AppChrome";
import Logo from "@/components/Logo";
import {
  ArrowDown,
  Handshake,
  Store,
  MapPin,
  Timer,
  Route,
  History,
  FlaskConical,
  Smartphone,
  Scale,
  Leaf,
  GraduationCap,
  ShieldCheck,
  Wheat,
  Ticket,
  PackageCheck,
} from "lucide-react";

// Dados do projeto acadêmico exibidos por padrão (continuam editáveis na página).
const DEFAULT_INFO = {
  instituicao: "Universidade Veiga de Almeida",
  curso: "Ciência da Computação",
  disciplina: "Projeto de Extensão V",
  semestre: "5º semestre",
  integrantes: "Bernardo Borges Moore, Gabriel Ferrara Portugal e João Pedro Souza Alves",
};
const INFO_STORAGE_KEY = "fomezero:about_info_v1";

const FIELD_CLASS =
  "w-full mt-1 bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-sm text-nr-text placeholder-nr-dim/30 focus:outline-none focus:border-nr-accent transition";

function Section({ title, children }) {
  return (
    <section className="space-y-4">
      <h2 className="text-xs font-semibold tracking-[0.18em] text-nr-dim/60 uppercase border-b border-nr-border pb-2">
        {title}
      </h2>
      {children}
    </section>
  );
}

function Card({ icon: Icon, title, desc }) {
  return (
    <div className="bg-nr-panel border border-nr-border rounded-xl p-4">
      <div className="flex items-center gap-2 mb-1.5">
        <Icon className="w-4 h-4 text-nr-accent flex-shrink-0" />
        <h3 className="text-sm font-semibold">{title}</h3>
      </div>
      <p className="text-xs text-nr-dim/70 leading-relaxed">{desc}</p>
    </div>
  );
}

function EditableField({ label, field, value, onChange, multiline = false, rows = 2 }) {
  return (
    <div>
      <label className="text-[11px] text-nr-dim/50 uppercase tracking-wide">{label}</label>
      {multiline ? (
        <textarea
          value={value}
          rows={rows}
          onChange={(e) => onChange(field, e.target.value)}
          placeholder="[Adicionar]"
          className={`${FIELD_CLASS} resize-none leading-relaxed`}
        />
      ) : (
        <input value={value} onChange={(e) => onChange(field, e.target.value)} placeholder="[Adicionar]" className={FIELD_CLASS} />
      )}
    </div>
  );
}

const STEPS = [
  { icon: Store, title: "Estabelecimento publica o excedente", desc: "Supermercados, hortifrútis e restaurantes cadastram alimentos próprios para consumo, com quantidade e validade." },
  { icon: MapPin, title: "A plataforma localiza por proximidade", desc: "As doações aparecem no mapa e na lista, ordenadas pela distância até a instituição ou pela urgência de validade." },
  { icon: Ticket, title: "Instituição reserva", desc: "A reserva é exclusiva e vale por até 2 horas, o que agiliza a retirada dos alimentos perecíveis." },
  { icon: Route, title: "Rota de coleta", desc: "As reservas são organizadas numa rota por proximidade geográfica, reduzindo deslocamentos." },
  { icon: PackageCheck, title: "Coleta e impacto registrados", desc: "A coleta confirmada entra no histórico e soma quilos resgatados e refeições estimadas." },
];

const FEATURES = [
  { icon: MapPin, title: "Mapa por proximidade", desc: "Doações e instituições ao redor da sua localização, com raio de busca ajustável." },
  { icon: Timer, title: "Prioridade para perecíveis", desc: "Alimentos perecíveis com pouca validade são marcados como urgentes e podem ser ordenados primeiro." },
  { icon: Ticket, title: "Reserva de mantimentos", desc: "Reserva exclusiva com código, prazo e opção de cancelamento." },
  { icon: Route, title: "Rota de coleta", desc: "Paradas ordenadas pelo vizinho mais próximo, com distância e tempo estimados." },
  { icon: History, title: "Histórico e impacto", desc: "Registro de publicações, reservas e coletas, com gráfico de alimento resgatado." },
  { icon: Smartphone, title: "Web e mobile", desc: "Layout responsivo que se adapta ao computador, ao tablet e ao celular." },
];

const RULES = [
  { id: "RN01", text: "Só podem ser publicados alimentos próprios para consumo: o estabelecimento precisa confirmar essa condição." },
  { id: "RN02", text: "A doação expira automaticamente quando a validade termina e deixa de aparecer como disponível." },
  { id: "RN03", text: "A reserva é exclusiva: enquanto uma instituição a mantém, nenhuma outra pode reservar a mesma doação." },
  { id: "RN04", text: "A reserva vale por até 2 horas (ou até a validade, se for menor). Se a coleta não for confirmada, a doação volta a ficar disponível." },
  { id: "RN05", text: "Perecíveis com menos de 3 horas de validade são marcados como urgentes; a lista pode ser ordenada por proximidade ou por urgência." },
  { id: "RN06", text: "Apenas estabelecimentos publicam doações e apenas instituições reservam e confirmam coletas." },
];

export default function Sobre() {
  const [info, setInfo] = useState(() => {
    try {
      return { ...DEFAULT_INFO, ...(JSON.parse(localStorage.getItem(INFO_STORAGE_KEY)) || {}) };
    } catch {
      return { ...DEFAULT_INFO };
    }
  });

  useEffect(() => {
    localStorage.setItem(INFO_STORAGE_KEY, JSON.stringify(info));
  }, [info]);

  const setField = (field, value) => setInfo((prev) => ({ ...prev, [field]: value }));

  return (
    <AppChrome>
      <div className="max-w-4xl mx-auto p-6 sm:p-8 space-y-10">
        {/* Hero */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-5">
          <div className="w-20 h-20 flex items-center justify-center text-nr-accent flex-shrink-0">
            <Logo className="w-20 h-20" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold font-heading tracking-wide">
              FOME <span className="text-nr-accent">ZERO</span>
            </h1>
            <p className="text-sm sm:text-base text-nr-dim/80 mt-1">Plataforma de Gestão e Doação de Alimentos Comunitários</p>
            <p className="text-xs text-nr-dim/50 mt-1">Alinhada ao Objetivo de Desenvolvimento Sustentável 2 (ODS 2) da Agenda 2030 da ONU.</p>
          </div>
        </div>

        <Section title="O problema e a proposta">
          <p className="text-sm text-nr-dim/80 leading-relaxed">
            O projeto enfrenta a insegurança alimentar e o desperdício de alimentos nas comunidades urbanas. O sistema conecta
            estabelecimentos comerciais (supermercados, hortifrútis e restaurantes) que têm excedentes próprios para consumo a
            instituições beneficentes, abrigos e cozinhas solidárias locais.
          </p>
          <p className="text-sm text-nr-dim/80 leading-relaxed">
            Ao otimizar a logística de recolhimento por proximidade geográfica e agilizar a reserva dos mantimentos perecíveis, a
            plataforma promove a distribuição eficiente de alimentos de qualidade para pessoas em situação de vulnerabilidade
            social, fortalecendo a solidariedade comunitária.
          </p>
        </Section>

        <Section title="Como funciona">
          <div className="flex flex-col items-stretch gap-2">
            {STEPS.map((s, i) => (
              <div key={s.title} className="flex flex-col items-stretch gap-2">
                <div className="flex items-start gap-3 bg-nr-panel border border-nr-border rounded-xl p-4">
                  <div className="w-9 h-9 rounded-lg bg-nr-accent/10 flex items-center justify-center flex-shrink-0">
                    <s.icon className="w-4 h-4 text-nr-accent" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold">
                      {i + 1}. {s.title}
                    </h3>
                    <p className="text-xs text-nr-dim/70 leading-relaxed mt-0.5">{s.desc}</p>
                  </div>
                </div>
                {i < STEPS.length - 1 && <ArrowDown className="w-4 h-4 text-nr-dim/30 self-center" />}
              </div>
            ))}
          </div>
        </Section>

        <Section title="Quem participa">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Card
              icon={Store}
              title="Estabelecimentos"
              desc="Supermercados, hortifrútis e restaurantes que possuem excedentes de alimentos próprios para consumo e querem doá-los em vez de descartá-los."
            />
            <Card
              icon={Handshake}
              title="Instituições"
              desc="Instituições beneficentes, abrigos e cozinhas solidárias locais que reservam e retiram os alimentos para atender pessoas em vulnerabilidade."
            />
          </div>
        </Section>

        <Section title="ODS 2 — Fome Zero e Agricultura Sustentável">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Card
              icon={Wheat}
              title="Meta 2.1"
              desc="Até 2030, acabar com a fome e garantir o acesso de todas as pessoas a alimentos seguros, nutritivos e suficientes durante o ano todo."
            />
            <Card
              icon={Leaf}
              title="Meta 12.3 (ODS 12, correlacionada)"
              desc="Reduzir pela metade o desperdício de alimentos per capita mundial, nos níveis de varejo e do consumidor, e reduzir as perdas ao longo das cadeias de produção e abastecimento."
            />
          </div>
        </Section>

        <Section title="Recursos do protótipo">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {FEATURES.map((f) => (
              <Card key={f.title} icon={f.icon} title={f.title} desc={f.desc} />
            ))}
          </div>
        </Section>

        <Section title="Regras de negócio implementadas no protótipo">
          <div className="bg-nr-panel border border-nr-border rounded-xl divide-y divide-nr-border">
            {RULES.map((r) => (
              <div key={r.id} className="flex items-start gap-3 px-4 py-3">
                <span className="text-[11px] font-mono font-bold text-nr-accent bg-nr-accent/10 rounded px-1.5 py-0.5 mt-0.5">
                  {r.id}
                </span>
                <p className="text-xs text-nr-dim/80 leading-relaxed">{r.text}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Sobre os dados deste protótipo">
          <div className="bg-nr-panel border border-nr-border rounded-xl p-4 space-y-2.5">
            <div className="flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-nr-demo" />
              <h3 className="text-sm font-semibold">Dados de demonstração</h3>
            </div>
            <p className="text-xs text-nr-dim/70 leading-relaxed">
              As doações e instituições marcadas com <span className="text-nr-demo font-semibold">DEMO</span> são fictícias e são
              geradas ao redor da sua localização apenas para demonstrar o funcionamento. Não representam estabelecimentos reais.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <ShieldCheck className="w-4 h-4 text-nr-accent" />
              <h3 className="text-sm font-semibold">Armazenamento local</h3>
            </div>
            <p className="text-xs text-nr-dim/70 leading-relaxed">
              Este é um protótipo navegável: as doações, reservas e o histórico ficam salvos apenas neste navegador, sem servidor.
              A troca de informações entre estabelecimentos e instituições de verdade exigiria um sistema com banco de dados
              compartilhado, como previsto na especificação da plataforma.
            </p>
          </div>
        </Section>

        <Section title="Projeto acadêmico">
          <div className="bg-nr-panel border border-nr-border rounded-xl p-5 space-y-4">
            <div>
              <div className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-nr-accent" />
                <h3 className="font-semibold">Fome Zero</h3>
              </div>
              <p className="text-sm text-nr-dim/70 mt-1">Plataforma de Gestão e Doação de Alimentos Comunitários</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <EditableField label="Instituição" field="instituicao" value={info.instituicao || ""} onChange={setField} />
              <EditableField label="Curso" field="curso" value={info.curso || ""} onChange={setField} />
              <EditableField label="Disciplina" field="disciplina" value={info.disciplina || ""} onChange={setField} />
              <EditableField label="Semestre" field="semestre" value={info.semestre || ""} onChange={setField} />
            </div>
            <EditableField label="Integrantes" field="integrantes" value={info.integrantes || ""} onChange={setField} multiline rows={3} />
          </div>
        </Section>

        <p className="flex items-center justify-center gap-1.5 text-[11px] text-nr-dim/40 pb-4">
          <Scale className="w-3 h-3" /> Fome Zero · Projeto de Extensão · ODS 2
        </p>
      </div>
    </AppChrome>
  );
}
