import { useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import AppChrome from "@/components/AppChrome";
import { useFoodEvents } from "@/hooks/useFoodBank";
import {
  EVENT_META,
  categoryById,
  computeImpact,
  establishmentTypeLabel,
  formatKg,
  kgPerDay,
} from "@/lib/food/offers";
import { History, PackageCheck, Scale, Soup, Store, Trash2, Search, TrendingUp } from "lucide-react";

const PERIODS = [
  { id: "all", label: "Todos" },
  { id: "today", label: "Hoje" },
  { id: "7d", label: "Últimos 7 dias" },
  { id: "30d", label: "Últimos 30 dias" },
];

function periodStart(id) {
  const now = new Date();
  if (id === "today") return new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  if (id === "7d") return now.getTime() - 7 * 86400000;
  if (id === "30d") return now.getTime() - 30 * 86400000;
  return 0;
}

function SummaryCard({ icon, label, value, sub }) {
  return (
    <div className="bg-nr-panel border border-nr-border rounded-xl p-4">
      <div className="flex items-center gap-2 text-nr-dim/60 text-[11px] uppercase tracking-wide">
        {icon} {label}
      </div>
      <p className="text-2xl font-semibold mt-2 break-words">{value}</p>
      {sub && <p className="text-[11px] text-nr-dim/50 mt-1">{sub}</p>}
    </div>
  );
}

function OriginBadge({ demo }) {
  return <span className={demo ? "text-nr-demo" : "text-nr-accent"}>{demo ? "🧪 DEMO" : "📍 Real"}</span>;
}

function EventChip({ type }) {
  const meta = EVENT_META[type] || { label: type, chip: "bg-nr-border text-nr-dim/60" };
  return <span className={`px-2 py-0.5 rounded-lg text-[11px] font-semibold whitespace-nowrap ${meta.chip}`}>{meta.label}</span>;
}

// Quilos de alimento coletados por dia (resgate que evita desperdício — ODS 12.3).
function KgChart({ events }) {
  const data = useMemo(() => kgPerDay(events), [events]);
  return (
    <div className="bg-nr-panel border border-nr-border rounded-xl p-4">
      <h2 className="text-sm font-semibold flex items-center gap-2 mb-3">
        <TrendingUp className="w-4 h-4 text-nr-accent" /> Alimento resgatado por dia
      </h2>
      {data.length > 0 ? (
        <div className="h-56 w-full bg-nr-bg rounded-xl border border-nr-border p-3">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 8, bottom: 5, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.25)" />
              <XAxis dataKey="label" tick={{ fill: "#94a3b8", fontSize: 10 }} stroke="rgba(148,163,184,0.35)" />
              <YAxis tick={{ fill: "#94a3b8", fontSize: 10 }} stroke="rgba(148,163,184,0.35)" />
              <Tooltip
                contentStyle={{ background: "#15211b", border: "1px solid #24362c", borderRadius: 8, fontSize: 12 }}
                labelStyle={{ color: "#cbd5e1" }}
                formatter={(v) => [`${v} kg`, "Coletado"]}
              />
              <Bar dataKey="kg" fill="#22c55e" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <p className="text-xs text-nr-dim/50 bg-nr-bg rounded-xl border border-nr-border p-4 text-center">
          Ainda não há coletas concluídas. Reserve uma doação e confirme a coleta para ver o impacto aqui.
        </p>
      )}
    </div>
  );
}

export default function Historico() {
  const { events, clear } = useFoodEvents();
  const [period, setPeriod] = useState("all");
  const [type, setType] = useState("all");
  const [origin, setOrigin] = useState("all");
  const [query, setQuery] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);

  const filtered = useMemo(() => {
    const start = periodStart(period);
    const q = query.trim().toLowerCase();
    return events.filter((e) => {
      if (new Date(e.timestamp).getTime() < start) return false;
      if (type !== "all" && e.type !== type) return false;
      if (origin === "demo" && !e.demo) return false;
      if (origin === "real" && e.demo) return false;
      if (q && ![e.item, e.establishmentName, e.institution].filter(Boolean).some((t) => t.toLowerCase().includes(q))) return false;
      return true;
    });
  }, [events, period, type, origin, query]);

  const impact = useMemo(() => computeImpact(filtered), [filtered]);

  return (
    <AppChrome>
      <div className="max-w-6xl mx-auto p-6 sm:p-8 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <History className="w-5 h-5 text-nr-accent" /> Histórico
          </h1>
          <p className="text-sm text-nr-dim/60 mt-1">
            Doações publicadas, reservas e coletas registradas no Fome Zero e o impacto acumulado.
          </p>
        </div>

        {/* Resumo de impacto */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <SummaryCard icon={<PackageCheck className="w-3.5 h-3.5" />} label="Coletas realizadas" value={impact.collections} />
          <SummaryCard icon={<Scale className="w-3.5 h-3.5" />} label="Alimento resgatado" value={formatKg(impact.kg)} sub="Evita desperdício (ODS 12.3)" />
          <SummaryCard icon={<Soup className="w-3.5 h-3.5" />} label="Refeições estimadas" value={`≈ ${impact.meals}`} sub="Estimativa: 1 refeição a cada 0,5 kg" />
          <SummaryCard
            icon={<Store className="w-3.5 h-3.5" />}
            label="Parceiros"
            value={`${impact.establishments} + ${impact.institutions}`}
            sub="Estabelecimentos + instituições"
          />
        </div>

        {/* Filtros */}
        <div className="bg-nr-panel border border-nr-border rounded-xl p-4 space-y-4">
          <div className="flex flex-wrap gap-2">
            {PERIODS.map((p) => (
              <button
                key={p.id}
                onClick={() => setPeriod(p.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
                  period === p.id
                    ? "bg-nr-accent/15 border-nr-accent text-nr-accent"
                    : "bg-nr-bg border-nr-border text-nr-dim/70 hover:border-nr-dim/40"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-xs text-nr-text focus:outline-none focus:border-nr-accent"
            >
              <option value="all">Evento: Todos</option>
              {Object.entries(EVENT_META).map(([id, m]) => (
                <option key={id} value={id}>
                  {m.label}
                </option>
              ))}
            </select>
            <select
              value={origin}
              onChange={(e) => setOrigin(e.target.value)}
              className="bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-xs text-nr-text focus:outline-none focus:border-nr-accent"
            >
              <option value="all">Origem: Todas</option>
              <option value="real">Reais (criadas por você)</option>
              <option value="demo">Demonstração</option>
            </select>
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-nr-dim/40" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Pesquisar alimento, estabelecimento ou instituição..."
                className="w-full bg-nr-bg border border-nr-border rounded-lg pl-9 pr-3 py-2 text-xs text-nr-text placeholder-nr-dim/30 focus:outline-none focus:border-nr-accent"
              />
            </div>
            <button
              onClick={() => {
                setPeriod("all");
                setType("all");
                setOrigin("all");
                setQuery("");
              }}
              className="px-3 py-2 rounded-lg text-xs font-medium border border-nr-border text-nr-dim/70 hover:text-nr-accent hover:border-nr-accent/60 transition whitespace-nowrap"
            >
              Limpar filtros
            </button>
          </div>
        </div>

        {/* Gráfico */}
        <KgChart events={filtered} />

        {/* Lista */}
        <div className="bg-nr-panel border border-nr-border rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-nr-border">
            <h2 className="text-sm font-semibold">Registro de eventos</h2>
            <button
              onClick={() => setConfirmClear(true)}
              disabled={!events.length}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-nr-border text-rose-400 hover:bg-rose-500/10 disabled:opacity-40 transition"
            >
              <Trash2 className="w-3.5 h-3.5" /> Limpar histórico
            </button>
          </div>

          {filtered.length === 0 ? (
            <div className="px-4 py-16 text-center text-nr-dim/40">
              <History className="w-8 h-8 mx-auto mb-3 opacity-40" />
              <p className="text-sm">Nenhum evento registrado ainda.</p>
              <p className="text-xs mt-1 max-w-xs mx-auto">
                Publicações, reservas e coletas feitas no mapa aparecem automaticamente aqui.
              </p>
            </div>
          ) : (
            <>
              {/* Tabela (desktop) */}
              <table className="hidden md:table w-full text-sm">
                <thead className="text-[11px] text-nr-dim/50 uppercase tracking-wide">
                  <tr className="border-b border-nr-border">
                    <th className="text-left font-medium px-4 py-2.5">Data e hora</th>
                    <th className="text-left font-medium px-4 py-2.5">Evento</th>
                    <th className="text-left font-medium px-4 py-2.5">Alimento</th>
                    <th className="text-left font-medium px-4 py-2.5">Estabelecimento</th>
                    <th className="text-left font-medium px-4 py-2.5">Instituição</th>
                    <th className="text-left font-medium px-4 py-2.5">Qtde.</th>
                    <th className="text-left font-medium px-4 py-2.5">Origem</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((e) => (
                    <tr key={e.id} className="border-b border-nr-border last:border-0 hover:bg-nr-dim/5">
                      <td className="px-4 py-3 text-nr-dim/80 whitespace-nowrap">{new Date(e.timestamp).toLocaleString("pt-BR")}</td>
                      <td className="px-4 py-3"><EventChip type={e.type} /></td>
                      <td className="px-4 py-3">
                        {e.item}
                        <span className="block text-[11px] text-nr-dim/40">{categoryById(e.category).label}</span>
                      </td>
                      <td className="px-4 py-3">
                        {e.establishmentName}
                        <span className="block text-[11px] text-nr-dim/40">{establishmentTypeLabel(e.establishmentType)}</span>
                      </td>
                      <td className="px-4 py-3">{e.institution || "—"}</td>
                      <td className="px-4 py-3 font-mono">{formatKg(e.quantityKg)}</td>
                      <td className="px-4 py-3"><OriginBadge demo={e.demo} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Cards (mobile) */}
              <div className="md:hidden divide-y divide-nr-border">
                {filtered.map((e) => (
                  <div key={e.id} className="p-4">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs text-nr-dim/70">{new Date(e.timestamp).toLocaleString("pt-BR")}</span>
                      <span className="text-xs"><OriginBadge demo={e.demo} /></span>
                    </div>
                    <div className="mt-2"><EventChip type={e.type} /></div>
                    <p className="text-sm font-medium mt-2">{e.item}</p>
                    <p className="text-xs text-nr-dim/60 mt-0.5">
                      {e.establishmentName}
                      {e.institution ? ` → ${e.institution}` : ""}
                    </p>
                    <p className="text-xs text-nr-dim/60 font-mono mt-1">{formatKg(e.quantityKg)}</p>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Confirmação limpar */}
      {confirmClear && (
        <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4" onClick={() => setConfirmClear(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div
            className="relative w-full max-w-sm rounded-2xl bg-nr-panel border border-nr-border shadow-2xl p-6 text-nr-text"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 mb-3">
              <Trash2 className="w-5 h-5 text-rose-400" />
              <h3 className="font-semibold">Limpar histórico</h3>
            </div>
            <p className="text-sm text-nr-dim/70">Tem certeza que deseja limpar todo o histórico?</p>
            <p className="text-xs text-nr-dim/50 mt-2">
              Esta ação removerá permanentemente os registros de doações, reservas e coletas deste navegador.
            </p>
            <div className="flex gap-2 mt-5">
              <button
                onClick={() => setConfirmClear(false)}
                className="flex-1 py-2 rounded-lg text-sm font-medium border border-nr-border text-nr-dim/80 hover:bg-nr-dim/10 transition"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  clear();
                  setConfirmClear(false);
                }}
                className="flex-1 py-2 rounded-lg text-sm font-medium bg-rose-500/90 hover:bg-rose-500 text-white transition"
              >
                Mesmo assim, limpar
              </button>
            </div>
          </div>
        </div>
      )}
    </AppChrome>
  );
}
