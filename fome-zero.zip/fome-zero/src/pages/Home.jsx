import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import FoodMap from "@/components/food/FoodMap";
import OfferList from "@/components/food/OfferList";
import OfferDetail from "@/components/food/OfferDetail";
import NewOfferModal from "@/components/food/NewOfferModal";
import ProfilePanel from "@/components/food/ProfilePanel";
import RoutePanel from "@/components/food/RoutePanel";
import ImpactCard from "@/components/food/ImpactCard";
import HelpMenu from "@/components/HelpMenu";
import SystemMenu from "@/components/SystemMenu";
import Logo from "@/components/Logo";
import BrandName from "@/components/BrandName";
import { useRadar } from "@/hooks/useRadar";
import { useFoodBank } from "@/hooks/useFoodBank";
import { useTheme } from "@/lib/theme";
import { describeAccuracy } from "@/lib/geo";
import { ROLES, STATUS, buildRoute, matchesQuery, withDistance } from "@/lib/food/offers";
import { Minus, X, Power, Loader2, MapPinOff, MapPin, Plus, CheckCircle2, AlertTriangle } from "lucide-react";

export default function Home() {
  const [selectedId, setSelectedId] = useState(null);
  const [systemOpen, setSystemOpen] = useState(false);
  const [newOpen, setNewOpen] = useState(false);
  const [notice, setNotice] = useState(null);
  const { theme, setTheme } = useTheme();
  const [config, setConfig] = useState({ radius: 2000, nameFilter: "" });

  // Tema é global (contexto); a config local guarda apenas os demais parâmetros.
  const handleConfigChange = (next) => {
    setTheme(next.theme);
    setConfig({ radius: next.radius, nameFilter: next.nameFilter });
  };

  const radar = useRadar(); // localização do usuário (a plataforma funciona por proximidade geográfica)
  const bank = useFoodBank({ userPos: radar.userPos });
  const { profile } = bank;
  const isInstitution = profile.role === ROLES.INSTITUICAO;
  const locationActive = radar.state === "active" && !!radar.userPos;

  // Mensagem de retorno das ações (some sozinha).
  useEffect(() => {
    if (!notice) return undefined;
    const t = setTimeout(() => setNotice(null), 4500);
    return () => clearTimeout(t);
  }, [notice]);

  const report = (res) => {
    setNotice({ type: res.ok ? "ok" : "error", text: res.message });
    return res;
  };

  // Fonte ÚNICA de doações para a lista E para o mapa (com a distância até o usuário).
  const withDist = useMemo(() => withDistance(bank.offers, radar.userPos), [bank.offers, radar.userPos]);

  // Disponíveis dentro do raio (busca por proximidade geográfica).
  const available = useMemo(
    () =>
      locationActive
        ? withDist.filter(
            (o) =>
              o.status === STATUS.DISPONIVEL &&
              o.distance <= config.radius &&
              matchesQuery(o, config.nameFilter)
          )
        : [],
    [withDist, locationActive, config.radius, config.nameFilter]
  );

  // "Minhas": reservas/coletas da instituição ou doações publicadas pelo estabelecimento.
  const mine = useMemo(() => {
    if (!locationActive) return [];
    if (isInstitution) {
      return withDist.filter(
        (o) => o.reservedById === profile.id && (o.status === STATUS.RESERVADA || o.status === STATUS.COLETADA)
      );
    }
    return withDist
      .filter((o) => !o.demo)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }, [withDist, locationActive, isInstitution, profile.id]);

  // Doações mostradas no mapa: disponíveis/reservadas no raio, mais as minhas.
  const mapOffers = useMemo(
    () =>
      locationActive
        ? withDist.filter(
            (o) =>
              (o.status === STATUS.DISPONIVEL || o.status === STATUS.RESERVADA) &&
              (o.distance <= config.radius || o.reservedById === profile.id || !o.demo) &&
              matchesQuery(o, config.nameFilter)
          )
        : [],
    [withDist, locationActive, config.radius, config.nameFilter, profile.id]
  );

  // Rota de coleta: reservas da instituição, por proximidade (vizinho mais próximo).
  const route = useMemo(() => {
    if (!locationActive || !isInstitution) return { stops: [], totalMeters: 0, minutes: 0 };
    const reserved = withDist.filter((o) => o.status === STATUS.RESERVADA && o.reservedById === profile.id);
    return buildRoute(radar.userPos, reserved);
  }, [withDist, locationActive, isInstitution, profile.id, radar.userPos]);

  const routePoints = useMemo(
    () => (route.stops.length ? [radar.userPos, ...route.stops.map((s) => [s.offer.latitude, s.offer.longitude])] : []),
    [route, radar.userPos]
  );
  const routeOrder = useMemo(() => Object.fromEntries(route.stops.map((s, i) => [s.offer.id, i + 1])), [route]);

  // Seleção válida apenas se a doação ainda existir (sincroniza lista ↔ mapa).
  const selected = selectedId && locationActive ? withDist.find((o) => o.id === selectedId) || null : null;

  const handleSubmitNew = (data) => {
    const res = report(bank.publish(data, radar.userPos));
    if (res.ok) setNewOpen(false);
    return res;
  };

  const statusText = !locationActive
    ? ""
    : available.length === 0
    ? "Localização ativa — nenhuma doação disponível no raio"
    : `Localização ativa — ${available.length} ${available.length === 1 ? "doação disponível" : "doações disponíveis"}`;

  return (
    <div className={`netradar-theme min-h-screen lg:h-screen w-full flex flex-col bg-nr-bg text-nr-text overflow-x-hidden lg:overflow-hidden font-body select-none ${theme === "light" ? "light" : ""}`}>
      {/* Title bar */}
      <header className="flex items-center justify-between h-[52px] px-4 bg-nr-bg border-b border-nr-border">
        <div className="flex items-center gap-2.5">
          <div className="h-[52px] w-[52px] flex items-center justify-center text-nr-accent">
            <Logo className="h-11 w-11" />
          </div>
          <BrandName />
        </div>
        <div className="flex items-center gap-1">
          <button className="w-7 h-7 rounded hover:bg-nr-dim/10 flex items-center justify-center text-nr-dim/70 transition">
            <Minus className="w-4 h-4" />
          </button>
          <button className="w-7 h-7 rounded hover:bg-rose-500/80 flex items-center justify-center text-nr-dim/70 transition">
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Menu bar */}
      <nav className="flex items-center gap-5 h-8 px-4 text-xs text-nr-dim/70 border-b border-nr-border">
        <button onClick={() => setSystemOpen(true)} className="hover:text-nr-accent cursor-pointer transition">Sistema</button>
        <Link to="/" className="hover:text-nr-accent cursor-pointer transition">Mapa</Link>
        <Link to="/historico" className="hover:text-nr-accent cursor-pointer transition">Histórico</Link>
        <HelpMenu />
      </nav>

      {/* Body */}
      {/* Celular (<768): 1 coluna vertical · Tablet (768–1023): painel | mapa + lista embaixo · Desktop (≥1024): 3 colunas */}
      <div className="flex-1 relative grid grid-cols-1 md:grid-cols-[320px_minmax(0,1fr)] lg:grid-cols-[280px_minmax(0,1fr)_300px] xl:grid-cols-[320px_minmax(0,1fr)_340px] lg:grid-rows-[minmax(0,1fr)] lg:min-h-0">
        {/* Left control panel */}
        <aside className="min-w-0 bg-nr-bg border-b md:border-b-0 md:border-r border-nr-border flex flex-col gap-4 p-4 lg:p-5 lg:min-h-0 lg:overflow-y-auto">
          <ProfilePanel
            role={profile.role}
            name={bank.currentName}
            onRoleChange={bank.setRole}
            onNameChange={bank.setName}
          />

          <div className="rounded-xl border border-nr-border p-3 flex flex-col gap-2.5">
            <button
              onClick={radar.togglePower}
              disabled={radar.state === "locating"}
              className="flex items-center justify-center gap-2 h-11 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition disabled:opacity-50"
            >
              {radar.state === "locating" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Power className="w-4 h-4" />}
              {radar.state === "active" ? "Desligar localização" : "Ativar localização"}
            </button>
            {!isInstitution && (
              <button
                onClick={() => setNewOpen(true)}
                disabled={!locationActive}
                title={locationActive ? "Publicar um excedente de alimentos" : "Ative a localização para publicar"}
                className="flex items-center justify-center gap-2 h-11 rounded-lg border border-nr-accent text-nr-accent hover:bg-nr-accent/10 text-sm font-medium transition disabled:opacity-40"
              >
                <Plus className="w-4 h-4" /> Nova doação
              </button>
            )}
          </div>

          {isInstitution && (
            <RoutePanel
              route={route}
              now={bank.now}
              onSelect={(o) => setSelectedId(o.id)}
              onConfirm={(o) => report(bank.confirmCollection(o.id))}
            />
          )}

          <ImpactCard events={bank.events} />

          {radar.state === "error" && <p className="text-[11px] text-rose-400 px-1">{radar.error}</p>}
        </aside>

        {/* Map */}
        <main className="relative min-w-0 h-[45vh] min-h-[350px] md:h-auto md:min-h-[480px] lg:min-h-0">
          <div className="absolute inset-0">
            <FoodMap
              userPos={radar.userPos}
              accuracy={radar.source === "gps" ? radar.accuracy : null}
              followUser={radar.source === "gps"}
              onUserMove={radar.setManualPos}
              offers={mapOffers}
              institutions={locationActive ? bank.institutions : []}
              selected={selected}
              onSelect={(o) => setSelectedId(o.id)}
              dark={theme === "dark"}
              radius={config.radius}
              routePoints={routePoints}
              routeOrder={routeOrder}
              now={bank.now}
            />
          </div>

          {radar.state === "off" && (
            <div className="absolute inset-0 bg-nr-bg/70 backdrop-blur-sm flex flex-col items-center justify-center z-[400] px-6 text-center">
              <Power className="w-10 h-10 text-nr-dim/30 mb-3" />
              <p className="text-sm text-nr-dim/70">Ative a localização para encontrar doações perto de você</p>
            </div>
          )}

          {radar.state === "error" && (
            <div className="absolute inset-0 bg-nr-bg/70 backdrop-blur-sm flex flex-col items-center justify-center z-[400] px-6 text-center">
              <MapPinOff className="w-10 h-10 text-rose-400/60 mb-3" />
              <p className="text-sm text-nr-dim/80 max-w-xs">{radar.error}</p>
              <button
                onClick={radar.togglePower}
                className="mt-4 px-4 py-2 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
              >
                Tentar novamente
              </button>
            </div>
          )}

          {radar.state === "locating" && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[400] flex items-center gap-2 bg-nr-panel px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-sm text-nr-dim/80 max-w-[calc(100%-20px)]">
              <Loader2 className="w-4 h-4 animate-spin text-nr-accent flex-shrink-0" />{" "}
              <span className="text-center">Obtendo localização…</span>
            </div>
          )}

          {locationActive && (
            <div className="absolute bottom-3 left-3 z-[400] bg-nr-panel/95 px-3 py-2 rounded-lg text-[11px] text-nr-dim/80 max-w-[calc(100%-24px)] space-y-1">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-nr-accent flex-shrink-0" />
                <span className="truncate">
                  Local da busca · raio {config.radius >= 1000 ? `${(config.radius / 1000).toFixed(1).replace(".", ",")} km` : `${config.radius} m`}
                </span>
              </div>
              <div className="font-mono text-[10px] text-nr-dim/60">
                {radar.userPos[0].toFixed(5)}, {radar.userPos[1].toFixed(5)}
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {radar.source === "manual" ? (
                  <span className="text-nr-accent">📍 Ajustado manualmente</span>
                ) : radar.accuracy != null ? (
                  <span
                    className={
                      describeAccuracy(radar.accuracy).level === "high"
                        ? "text-emerald-400"
                        : describeAccuracy(radar.accuracy).level === "low"
                        ? "text-rose-400"
                        : "text-amber-400"
                    }
                  >
                    Precisão ±{Math.round(radar.accuracy)} m ({describeAccuracy(radar.accuracy).label})
                  </span>
                ) : (
                  <span>Precisão desconhecida</span>
                )}
                {radar.refining && (
                  <span className="flex items-center gap-1 text-nr-dim/60">
                    <Loader2 className="w-3 h-3 animate-spin" /> refinando…
                  </span>
                )}
                {!radar.refining && (radar.source === "manual" || (radar.accuracy ?? 0) > 25) && (
                  <button onClick={radar.refreshLocation} className="underline text-nr-accent hover:opacity-80">
                    {radar.source === "manual" ? "Usar localização do aparelho" : "Atualizar localização"}
                  </button>
                )}
              </div>
              {radar.source === "gps" && !radar.refining && (radar.accuracy ?? 0) > 50 && (
                <p className="text-[10px] text-nr-dim/50 max-w-[260px]">
                  Dica: arraste o marcador azul no mapa para o local exato.
                </p>
              )}
            </div>
          )}

          {locationActive && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[400] flex items-center gap-2 bg-nr-panel px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-sm text-nr-dim/80 max-w-[calc(100%-20px)]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0" />
              <span className="text-center">{statusText}</span>
            </div>
          )}

          {/* Legenda do mapa */}
          {locationActive && (
            <div className="hidden sm:flex absolute bottom-3 right-3 z-[400] flex-col gap-1 bg-nr-panel/95 px-3 py-2 rounded-lg text-[10px] text-nr-dim/70">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-400" /> Disponível</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-400" /> Reservada</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full border-2 border-rose-400" /> Urgente (perecível)</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-blue-400" /> Instituição</span>
            </div>
          )}

          {/* Mensagem de retorno das ações */}
          {notice && (
            <div
              className={`absolute top-14 left-1/2 -translate-x-1/2 z-[1100] flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium shadow-lg max-w-[calc(100%-24px)] ${
                notice.type === "ok" ? "bg-emerald-600 text-white" : "bg-rose-600 text-white"
              }`}
              role="status"
            >
              {notice.type === "ok" ? <CheckCircle2 className="w-4 h-4 flex-shrink-0" /> : <AlertTriangle className="w-4 h-4 flex-shrink-0" />}
              <span>{notice.text}</span>
            </div>
          )}
        </main>

        {/* Right panel — mesma fonte de dados do mapa */}
        <aside className="min-w-0 bg-nr-bg border-t lg:border-t-0 lg:border-l border-nr-border h-[60vh] md:col-span-2 md:h-[50vh] md:min-h-[360px] lg:col-span-1 lg:h-auto lg:min-h-0">
          <OfferList
            available={available}
            mine={mine}
            role={profile.role}
            selected={selected}
            onSelect={(o) => setSelectedId(o.id)}
            locationActive={locationActive}
            showDemo={bank.showDemo}
            onToggleDemo={bank.setShowDemo}
            now={bank.now}
          />
        </aside>

        {selected && (
          <OfferDetail
            offer={selected}
            role={profile.role}
            profileId={profile.id}
            now={bank.now}
            onReserve={() => report(bank.reserve(selected.id))}
            onCancelReservation={() => report(bank.cancelReservation(selected.id))}
            onConfirmCollection={() => report(bank.confirmCollection(selected.id))}
            onCancelOffer={() => report(bank.cancelOffer(selected.id))}
            onClose={() => setSelectedId(null)}
          />
        )}

        {newOpen && (
          <NewOfferModal
            open
            defaultName={bank.currentName}
            locationReady={locationActive}
            onSubmit={handleSubmitNew}
            onClose={() => setNewOpen(false)}
          />
        )}

        <SystemMenu
          open={systemOpen}
          onClose={() => setSystemOpen(false)}
          config={{ ...config, theme }}
          onChange={handleConfigChange}
          showDemo={bank.showDemo}
          onToggleDemo={bank.setShowDemo}
          onResetDemo={bank.resetDemo}
        />
      </div>
    </div>
  );
}
