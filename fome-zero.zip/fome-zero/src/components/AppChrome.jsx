import { useState } from "react";
import { Link } from "react-router-dom";
import Logo from "@/components/Logo";
import BrandName from "@/components/BrandName";
import HelpMenu from "@/components/HelpMenu";
import SystemMenu from "@/components/SystemMenu";
import { useTheme } from "@/lib/theme";
import { Minus, X } from "lucide-react";

// Chrome compartilhado (barra de título + menu) das páginas internas do Fome Zero.
export default function AppChrome({ children }) {
  const [systemOpen, setSystemOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const [config, setConfig] = useState({ radius: 2000, nameFilter: "" });

  // Tema é global (contexto); a config local guarda apenas os demais parâmetros.
  const handleConfigChange = (next) => {
    setTheme(next.theme);
    setConfig({ radius: next.radius, nameFilter: next.nameFilter });
  };

  return (
    <div
      className={`netradar-theme relative h-screen w-screen flex flex-col bg-nr-bg text-nr-text overflow-hidden font-body select-none ${
        theme === "light" ? "light" : ""
      }`}
    >
      {/* Title bar */}
      <header className="flex items-center justify-between h-[52px] px-4 bg-nr-bg border-b border-nr-border">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="h-[52px] w-[52px] flex items-center justify-center text-nr-accent">
            <Logo className="h-11 w-11" />
          </div>
          <BrandName />
        </Link>
        <div className="flex items-center gap-1">
          <button className="w-7 h-7 rounded hover:bg-nr-dim/10 flex items-center justify-center text-nr-dim/70 transition">
            <Minus className="w-4 h-4" />
          </button>
          <Link
            to="/"
            className="w-7 h-7 rounded hover:bg-rose-500/80 flex items-center justify-center text-nr-dim/70 transition"
            title="Voltar ao mapa"
          >
            <X className="w-4 h-4" />
          </Link>
        </div>
      </header>

      {/* Menu bar */}
      <nav className="flex items-center gap-5 h-8 px-4 text-xs text-nr-dim/70 border-b border-nr-border">
        <button onClick={() => setSystemOpen(true)} className="hover:text-nr-accent cursor-pointer transition">
          Sistema
        </button>
        <Link to="/" className="hover:text-nr-accent cursor-pointer transition">Mapa</Link>
        <Link to="/historico" className="hover:text-nr-accent cursor-pointer transition">
          Histórico
        </Link>
        <HelpMenu />
      </nav>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">{children}</div>

      <SystemMenu open={systemOpen} onClose={() => setSystemOpen(false)} config={{ ...config, theme }} onChange={handleConfigChange} />
    </div>
  );
}