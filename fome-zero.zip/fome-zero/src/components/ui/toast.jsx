import React, { createContext, useContext } from "react";

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  return <>{children}</>;
}

export function Toast({
  open = true,
  onOpenChange,
  className = "",
  children,
  variant = "default",
  ...props
}) {
  if (!open) return null;

  return (
    <ToastContext.Provider value={{ onOpenChange }}>
      <div
        role="status"
        className={`pointer-events-auto relative flex w-full items-center justify-between gap-4 overflow-hidden rounded-md border p-4 shadow-lg bg-background text-foreground ${variant === "destructive" ? "border-red-500" : ""} ${className}`}
        {...props}
      >
        {children}
      </div>
    </ToastContext.Provider>
  );
}

export function ToastTitle({ children, className = "", ...props }) {
  return (
    <div
      className={`text-sm font-semibold ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}

export function ToastDescription({ children, className = "", ...props }) {
  return (
    <div
      className={`text-sm opacity-90 ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}

export function ToastClose({ className = "", ...props }) {
  const context = useContext(ToastContext);

  return (
    <button
      type="button"
      aria-label="Fechar notificação"
      onClick={() => context?.onOpenChange?.(false)}
      className={`absolute right-2 top-2 rounded-md p-1 text-sm opacity-70 hover:opacity-100 ${className}`}
      {...props}
    >
      ×
    </button>
  );
}

export function ToastViewport({ className = "", ...props }) {
  return (
    <div
      className={`fixed bottom-0 right-0 z-[100] flex max-h-screen w-full flex-col-reverse gap-2 p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px] ${className}`}
      {...props}
    />
  );
}