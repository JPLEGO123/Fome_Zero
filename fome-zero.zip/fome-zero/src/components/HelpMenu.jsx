import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ChevronDown, Info } from "lucide-react";

// Menu "Ajuda" do menu superior — contém "Sobre o Fome Zero".
export default function HelpMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="hover:text-nr-accent cursor-pointer transition flex items-center gap-1"
      >
        Ajuda <ChevronDown className="w-3 h-3" />
      </button>
      {open && (
        <div className="absolute top-full left-0 mt-1 w-48 bg-nr-panel border border-nr-border rounded-lg shadow-xl py-1 z-[1100]">
          <Link
            to="/sobre"
            onClick={() => setOpen(false)}
            className="flex items-center gap-2 px-3 py-2 text-xs hover:bg-nr-dim/10 hover:text-nr-accent transition"
          >
            <Info className="w-3.5 h-3.5" /> Sobre o Fome Zero
          </Link>
        </div>
      )}
    </div>
  );
}
