import React from "react";
import { Clock, Flame, MapPin, Scale } from "lucide-react";
import CategoryIcon from "./CategoryIcon";
import {
  STATUS_META,
  categoryById,
  establishmentTypeLabel,
  formatDistance,
  formatKg,
  timeLeft,
} from "@/lib/food/offers";

// Cartão de uma doação na lista lateral.
export default function OfferCard({ offer, selected, onSelect, now }) {
  const meta = STATUS_META[offer.status] || STATUS_META.disponivel;
  const left = timeLeft(offer, now);
  const urgent = left.urgent && offer.status === "disponivel";
  return (
    <button
      onClick={onSelect}
      className={`w-full text-left px-4 py-3 border-b border-nr-border transition flex gap-3 ${
        selected ? "bg-nr-accent/10" : "hover:bg-nr-dim/5"
      }`}
    >
      <div className="w-9 h-9 rounded-lg bg-nr-panel border border-nr-border flex items-center justify-center text-nr-accent flex-shrink-0">
        <CategoryIcon category={offer.category} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <p className="text-sm font-medium leading-snug">{offer.item}</p>
          <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold whitespace-nowrap ${meta.chip}`}>
            {meta.label}
          </span>
        </div>
        <p className="text-[11px] text-nr-dim/50 mt-0.5 truncate">
          {offer.establishmentName} · {establishmentTypeLabel(offer.establishmentType)}
        </p>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-[11px] text-nr-dim/70">
          <span className="flex items-center gap-1">
            <Scale className="w-3 h-3" /> {formatKg(offer.quantityKg)}
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3" /> {formatDistance(offer.distance)}
          </span>
          <span className={`flex items-center gap-1 ${urgent ? "text-rose-400 font-semibold" : ""}`}>
            {urgent ? <Flame className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
            {left.label}
          </span>
        </div>
        <div className="flex items-center gap-1.5 mt-1.5">
          <span className="text-[10px] text-nr-dim/40">{categoryById(offer.category).label}</span>
          {urgent && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-400">URGENTE</span>
          )}
          {offer.demo && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-nr-demo/20 text-nr-demo tracking-wider">
              DEMO
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
