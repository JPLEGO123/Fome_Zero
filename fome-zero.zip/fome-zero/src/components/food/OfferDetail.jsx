import React from "react";
import { X, Store, Scale, Clock, MapPin, Hourglass, Ticket, CheckCircle2, Ban, Info, Flame } from "lucide-react";
import CategoryIcon from "./CategoryIcon";
import {
  ROLES,
  STATUS,
  STATUS_META,
  categoryById,
  establishmentTypeLabel,
  estimateMinutes,
  formatDistance,
  formatDuration,
  formatKg,
  mealsFromKg,
  timeLeft,
} from "@/lib/food/offers";

function Row({ icon, label, children }) {
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-nr-border">
      <div className="text-nr-accent/70 mt-0.5">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-[11px] text-nr-dim/40 uppercase tracking-wide">{label}</p>
        <p className="mt-0.5 break-words">{children}</p>
      </div>
    </div>
  );
}

const fmtDateTime = (iso) =>
  new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });

// Painel com os detalhes da doação e as ações permitidas para o perfil atual.
export default function OfferDetail({ offer, role, profileId, now, onReserve, onCancelReservation, onConfirmCollection, onCancelOffer, onClose }) {
  const meta = STATUS_META[offer.status] || STATUS_META.disponivel;
  const left = timeLeft(offer, now);
  const urgent = left.urgent && offer.status === STATUS.DISPONIVEL;
  const isInstitution = role === ROLES.INSTITUICAO;
  const mineReservation = offer.status === STATUS.RESERVADA && offer.reservedById === profileId;

  let actions = null;
  if (offer.status === STATUS.DISPONIVEL && isInstitution) {
    actions = (
      <button
        onClick={onReserve}
        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
      >
        <Ticket className="w-4 h-4" /> Reservar esta doação
      </button>
    );
  } else if (offer.status === STATUS.DISPONIVEL && !isInstitution) {
    actions = (
      <div className="space-y-2.5">
        <p className="flex items-start gap-2 text-xs text-nr-dim/60">
          <Info className="w-4 h-4 flex-shrink-0 mt-px" />
          Para reservar, troque o perfil para Instituição no painel à esquerda.
        </p>
        {!offer.demo && (
          <button
            onClick={onCancelOffer}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-nr-border text-rose-400 hover:bg-rose-500/10 text-sm font-medium transition"
          >
            <Ban className="w-4 h-4" /> Cancelar esta doação
          </button>
        )}
      </div>
    );
  } else if (mineReservation) {
    actions = (
      <div className="space-y-2.5">
        <button
          onClick={onConfirmCollection}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
        >
          <CheckCircle2 className="w-4 h-4" /> Confirmar coleta
        </button>
        <button
          onClick={onCancelReservation}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-nr-border text-nr-dim/80 hover:bg-nr-dim/10 text-sm font-medium transition"
        >
          <Ban className="w-4 h-4" /> Cancelar reserva
        </button>
      </div>
    );
  } else if (offer.status === STATUS.RESERVADA) {
    actions = (
      <p className="flex items-start gap-2 text-xs text-nr-dim/60">
        <Info className="w-4 h-4 flex-shrink-0 mt-px" />
        Esta doação está reservada por outra instituição. Se a reserva não for retirada a tempo, ela volta a ficar disponível.
      </p>
    );
  }

  return (
    <div className="fixed sm:absolute right-0 top-0 bottom-0 w-full sm:w-[360px] bg-nr-bg border-l border-nr-border z-[1000] flex flex-col text-nr-text">
      <div className="flex items-center justify-between px-5 py-4 border-b border-nr-border">
        <h3 className="font-semibold">Detalhes da doação</h3>
        <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/50 transition">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-xl bg-nr-panel border border-nr-border flex items-center justify-center text-nr-accent flex-shrink-0">
            <CategoryIcon category={offer.category} className="w-6 h-6" />
          </div>
          <div className="min-w-0">
            <h4 className="font-semibold leading-tight">{offer.item}</h4>
            <p className="text-xs text-nr-dim/40 mt-0.5">{categoryById(offer.category).label}</p>
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              <span className={`px-2 py-0.5 rounded-lg text-xs font-semibold ${meta.chip}`}>{meta.label}</span>
              {urgent && (
                <span className="flex items-center gap-1 px-2 py-0.5 rounded-lg text-xs font-bold bg-rose-500/15 text-rose-400">
                  <Flame className="w-3 h-3" /> URGENTE
                </span>
              )}
              {offer.demo && (
                <span className="px-2 py-0.5 rounded-lg text-xs font-bold bg-nr-demo/20 text-nr-demo tracking-wider">DEMO</span>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-1 text-sm">
          <Row icon={<Store className="w-4 h-4" />} label="Estabelecimento">
            {offer.establishmentName}
            <span className="text-nr-dim/50"> · {establishmentTypeLabel(offer.establishmentType)}</span>
          </Row>
          <Row icon={<Scale className="w-4 h-4" />} label="Quantidade">
            {formatKg(offer.quantityKg)}
            <span className="text-nr-dim/50"> · ≈ {mealsFromKg(offer.quantityKg)} refeições (estimativa)</span>
          </Row>
          <Row icon={<Clock className="w-4 h-4" />} label="Retirar até">
            {fmtDateTime(offer.validUntil)}
            <span className={left.urgent ? "text-rose-400 font-semibold" : "text-nr-dim/50"}> · restam {left.label}</span>
          </Row>
          <Row icon={<MapPin className="w-4 h-4" />} label="Distância (linha reta)">
            {formatDistance(offer.distance)}
            {offer.distance != null && (
              <span className="text-nr-dim/50"> · ≈ {estimateMinutes(offer.distance)} min de carro</span>
            )}
          </Row>
          {offer.status === STATUS.RESERVADA && (
            <>
              <Row icon={<Ticket className="w-4 h-4" />} label="Reservada por">
                {offer.reservedBy}
                {offer.reservationCode && <span className="font-mono text-nr-accent"> · {offer.reservationCode}</span>}
              </Row>
              <Row icon={<Hourglass className="w-4 h-4" />} label="A reserva expira em">
                {formatDuration(new Date(offer.reservedUntil).getTime() - now)}
              </Row>
            </>
          )}
          {offer.status === STATUS.COLETADA && offer.collectedAt && (
            <Row icon={<CheckCircle2 className="w-4 h-4" />} label="Coletada em">
              {fmtDateTime(offer.collectedAt)}
              {offer.reservedBy && <span className="text-nr-dim/50"> · {offer.reservedBy}</span>}
            </Row>
          )}
          {offer.notes && (
            <Row icon={<Info className="w-4 h-4" />} label="Observações">
              {offer.notes}
            </Row>
          )}
        </div>

        {actions}
      </div>
    </div>
  );
}
