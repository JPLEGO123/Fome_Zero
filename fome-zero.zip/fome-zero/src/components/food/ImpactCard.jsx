import React from "react";
import { Link } from "react-router-dom";
import { Scale, Soup, PackageCheck, Leaf } from "lucide-react";
import { computeImpact, formatKg } from "@/lib/food/offers";

function Stat({ icon, label, value }) {
  return (
    <div className="rounded-lg bg-nr-bg border border-nr-border p-2.5 min-w-0">
      <div className="flex items-center gap-1.5 text-nr-dim/40">
        {icon}
        <span className="text-[10px] uppercase tracking-wide truncate">{label}</span>
      </div>
      <p className="text-sm font-semibold mt-1 truncate">{value}</p>
    </div>
  );
}

// Impacto acumulado (ODS 2 · meta 2.1 e meta 12.3): alimento resgatado em vez de desperdiçado.
export default function ImpactCard({ events }) {
  const impact = computeImpact(events);
  return (
    <div className="rounded-xl bg-nr-panel p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-nr-dim/50">Impacto (ODS 2)</span>
        <Leaf className="w-4 h-4 text-nr-accent" />
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        <Stat icon={<PackageCheck className="w-3 h-3" />} label="Coletas" value={impact.collections} />
        <Stat icon={<Scale className="w-3 h-3" />} label="Resgatado" value={formatKg(impact.kg)} />
        <Stat icon={<Soup className="w-3 h-3" />} label="Refeições" value={`≈ ${impact.meals}`} />
        <Stat icon={<Leaf className="w-3 h-3" />} label="Publicadas" value={impact.published} />
      </div>
      <Link to="/historico" className="block text-[11px] underline text-nr-accent hover:opacity-80">
        Ver histórico completo
      </Link>
    </div>
  );
}
