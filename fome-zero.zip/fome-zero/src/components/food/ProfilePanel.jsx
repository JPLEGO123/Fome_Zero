import React from "react";
import { Handshake, Store } from "lucide-react";
import { ROLES } from "@/lib/food/offers";

const ROLE_OPTIONS = [
  {
    id: ROLES.INSTITUICAO,
    label: "Instituição",
    Icon: Handshake,
    hint: "Abrigos, cozinhas solidárias e instituições beneficentes: reservam e coletam doações.",
    nameLabel: "Nome da instituição",
  },
  {
    id: ROLES.ESTABELECIMENTO,
    label: "Estabelecimento",
    Icon: Store,
    hint: "Supermercados, hortifrútis e restaurantes: publicam excedentes próprios para consumo.",
    nameLabel: "Nome do estabelecimento",
  },
];

// Perfil de uso do protótipo: quem está usando a plataforma (define as ações permitidas).
export default function ProfilePanel({ role, name, onRoleChange, onNameChange }) {
  const current = ROLE_OPTIONS.find((r) => r.id === role) || ROLE_OPTIONS[0];
  return (
    <div className="rounded-xl bg-nr-panel p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-nr-dim/50">Quem está usando?</span>
        <current.Icon className="w-4 h-4 text-nr-accent" />
      </div>
      <div className="grid grid-cols-2 gap-2">
        {ROLE_OPTIONS.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => onRoleChange(id)}
            className={`flex items-center justify-center gap-1.5 h-10 rounded-lg border text-xs font-medium transition ${
              role === id
                ? "bg-nr-accent/15 border-nr-accent text-nr-accent"
                : "bg-nr-bg border-nr-border text-nr-dim/70 hover:border-nr-dim/40"
            }`}
          >
            <Icon className="w-3.5 h-3.5" /> {label}
          </button>
        ))}
      </div>
      <div>
        <label className="text-[11px] text-nr-dim/50 uppercase tracking-wide">{current.nameLabel}</label>
        <input
          value={name}
          onChange={(e) => onNameChange(e.target.value)}
          className="w-full mt-1 bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-sm text-nr-text focus:outline-none focus:border-nr-accent transition"
        />
      </div>
      <p className="text-[11px] text-nr-dim/50 leading-relaxed">{current.hint}</p>
    </div>
  );
}
