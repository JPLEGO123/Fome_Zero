import React, { useMemo, useState } from "react";
import { ArrowUpDown, Heart, MapPinOff, Power } from "lucide-react";
import OfferCard from "./OfferCard";
import { ROLES, sortOffers } from "@/lib/food/offers";

const TABS = {
  disponiveis: "Disponíveis",
  minhas: "Minhas",
};

// Lista lateral de doações. Compartilha a mesma fonte de dados do mapa.
// - Aba "Disponíveis": doações ainda livres dentro do raio, por proximidade ou urgência.
// - Aba "Minhas": reservas/coletas da instituição ou doações publicadas pelo estabelecimento.
export default function OfferList({
  available,
  mine,
  role,
  selected,
  onSelect,
  locationActive,
  showDemo,
  onToggleDemo,
  now,
}) {
  const [tab, setTab] = useState("disponiveis");
  const [sort, setSort] = useState("proximidade");

  const shown = useMemo(() => {
    if (tab === "minhas") return mine;
    return sortOffers(available, sort);
  }, [tab, sort, available, mine]);

  const mineLabel = role === ROLES.ESTABELECIMENTO ? "Minhas doações" : "Minhas reservas";

  return (
    <div className="flex flex-col h-full bg-nr-bg text-nr-text">
      <div className="px-4 pt-3.5 pb-3 border-b border-nr-border space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold flex items-center gap-2">
              <Heart className="w-4 h-4 text-nr-accent" /> Doações próximas
            </h2>
            <p className="text-[11px] text-nr-dim/40">
              {locationActive
                ? tab === "minhas"
                  ? `${mine.length} em ${mineLabel.toLowerCase()}`
                  : `${available.length} ${available.length === 1 ? "disponível" : "disponíveis"} no raio`
                : "Aguardando localização"}
            </p>
          </div>
        </div>

        {/* Abas */}
        <div className="grid grid-cols-2 gap-1 p-1 rounded-lg bg-nr-panel border border-nr-border">
          {Object.entries(TABS).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`py-1.5 rounded-md text-xs font-medium transition ${
                tab === id ? "bg-nr-accent/15 text-nr-accent" : "text-nr-dim/60 hover:text-nr-dim"
              }`}
            >
              {id === "minhas" ? mineLabel : label}
            </button>
          ))}
        </div>

        {/* Ordenação (RN05: proximidade e urgência) */}
        {tab === "disponiveis" && (
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-3.5 h-3.5 text-nr-dim/40" />
            {[
              { id: "proximidade", label: "Mais próximas" },
              { id: "urgencia", label: "Mais urgentes" },
            ].map((o) => (
              <button
                key={o.id}
                onClick={() => setSort(o.id)}
                className={`px-2.5 py-1 rounded-full text-[11px] font-medium border transition ${
                  sort === o.id
                    ? "bg-nr-accent/15 border-nr-accent text-nr-accent"
                    : "bg-nr-bg border-nr-border text-nr-dim/60 hover:border-nr-dim/40"
                }`}
              >
                {o.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto">
        {!locationActive ? (
          <div className="px-4 py-16 text-center text-nr-dim/40">
            <Power className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p className="text-sm">Localização desligada</p>
            <p className="text-xs mt-1">Ative a localização para ver as doações perto de você.</p>
          </div>
        ) : shown.length === 0 ? (
          <div className="px-4 py-16 text-center text-nr-dim/40">
            <MapPinOff className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p className="text-sm">
              {tab === "minhas"
                ? role === ROLES.ESTABELECIMENTO
                  ? "Você ainda não publicou doações"
                  : "Você ainda não reservou doações"
                : "Nenhuma doação disponível no raio"}
            </p>
            <p className="text-xs mt-1 max-w-[230px] mx-auto">
              {tab === "minhas"
                ? role === ROLES.ESTABELECIMENTO
                  ? "Use o botão “Nova doação” para publicar um excedente."
                  : "Escolha uma doação disponível e toque em “Reservar”."
                : "Aumente o raio em Sistema ou ative os dados de demonstração."}
            </p>
          </div>
        ) : (
          shown.map((o) => (
            <OfferCard key={o.id} offer={o} selected={selected?.id === o.id} onSelect={() => onSelect(o)} now={now} />
          ))
        )}
      </div>

      <label className="flex items-center gap-2 px-4 py-2.5 border-t border-nr-border text-[11px] text-nr-dim/60 cursor-pointer">
        <input
          type="checkbox"
          checked={!!showDemo}
          onChange={(e) => onToggleDemo(e.target.checked)}
          className="w-3.5 h-3.5 accent-nr-accent"
        />
        Mostrar dados de demonstração (fictícios)
      </label>
    </div>
  );
}
