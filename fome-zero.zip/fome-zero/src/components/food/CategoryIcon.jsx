import { Apple, Croissant, Milk, Package, Soup } from "lucide-react";

const ICONS = {
  hortifruti: Apple,
  prontos: Soup,
  padaria: Croissant,
  laticinios: Milk,
  secos: Package,
};

// Ícone da categoria do alimento.
export default function CategoryIcon({ category, className = "w-4 h-4" }) {
  const Icon = ICONS[category] || Package;
  return <Icon className={className} />;
}
