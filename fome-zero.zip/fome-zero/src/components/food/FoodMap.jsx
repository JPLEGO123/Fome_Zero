import React, { useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup, Tooltip, useMap, Circle, Polyline } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import {
  STATUS_META,
  categoryById,
  establishmentTypeLabel,
  formatDistance,
  formatKg,
  timeLeft,
} from "@/lib/food/offers";

const HEART =
  '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>';
const HOUSE = '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>';

const svg = (inner, color, size = 15) =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;

// Marcador de doação: círculo na cor do status, com coração (ou o número da parada na rota).
// Doações urgentes ganham um anel pulsante.
function offerIcon(offer, dark, routeIndex, urgent) {
  const meta = STATUS_META[offer.status] || STATUS_META.disponivel;
  const color = dark ? meta.marker : meta.markerLight;
  const inner = routeIndex
    ? `<span style="font:700 12px/1 Inter,system-ui,sans-serif;color:${color}">${routeIndex}</span>`
    : svg(HEART, color);
  const ring = urgent
    ? `<div class="fz-pulse" style="position:absolute;inset:-5px;border-radius:50%;border:2px solid #f43f5e;"></div>`
    : "";
  return L.divIcon({
    html: `<div style="position:relative;width:28px;height:28px;">
      ${ring}
      <div style="position:absolute;inset:0;border-radius:50%;background:${color}26;border:2px solid ${color};box-shadow:0 0 0 3px ${color}1a,0 0 8px ${color}66;"></div>
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">${inner}</div>
    </div>`,
    className: "",
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
}

// Marcador de instituição (demonstração): quadrado azul com casa.
function institutionIcon(dark) {
  const color = dark ? "#60a5fa" : "#1d4ed8";
  return L.divIcon({
    html: `<div style="width:24px;height:24px;border-radius:7px;background:${color}22;border:2px solid ${color};display:flex;align-items:center;justify-content:center;">${svg(HOUSE, color, 13)}</div>`,
    className: "",
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
}

// Marcador do usuário.
const userIcon = L.divIcon({
  html: `<div style="width:14px;height:14px;border-radius:50%;background:#2563eb;border:3px solid #fff;box-shadow:0 0 0 6px rgba(37,99,235,.25),0 0 12px rgba(37,99,235,.6);"></div>`,
  className: "",
  iconSize: [14, 14],
  iconAnchor: [7, 7],
});

// Recalcula o tamanho do mapa sempre que o container muda (resize, breakpoint,
// orientação, abertura/fechamento de painéis) — sem recriar o mapa.
function MapResizer() {
  const map = useMap();

  useEffect(() => {
    const invalidate = () => requestAnimationFrame(() => map.invalidateSize({ animate: false, pan: false }));
    invalidate();
    const t = setTimeout(invalidate, 250);
    window.addEventListener("resize", invalidate);
    window.addEventListener("orientationchange", invalidate);
    let ro;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver(invalidate);
      ro.observe(map.getContainer());
    }
    return () => {
      clearTimeout(t);
      window.removeEventListener("resize", invalidate);
      window.removeEventListener("orientationchange", invalidate);
      if (ro) ro.disconnect();
    };
  }, [map]);

  return null;
}

// Enquadra o mapa na área de busca (círculo do raio). Reenquadra quando o raio muda e, enquanto a
// posição vem do GPS (`followUser`), quando ela melhora. Se o usuário ajusta o marcador na mão,
// não reenquadra (o mapa não "pula" a cada arrasto).
function FitSearchArea({ center, radius, followUser }) {
  const map = useMap();
  const lastRef = useRef({ radius: null, fitted: false });
  useEffect(() => {
    if (!center) {
      lastRef.current = { radius: null, fitted: false };
      return undefined;
    }
    const radiusChanged = lastRef.current.radius !== radius;
    if (lastRef.current.fitted && !radiusChanged && !followUser) return undefined;
    const t = setTimeout(() => {
      map.invalidateSize({ animate: false, pan: false });
      // Quadrado de lado 2×raio centrado no usuário (cobre todo o círculo de busca).
      const bounds = L.latLng(center[0], center[1]).toBounds(radius * 2);
      map.fitBounds(bounds, { padding: [30, 30], maxZoom: 18, animate: true });
      lastRef.current = { radius, fitted: true };
    }, 300);
    return () => clearTimeout(t);
  }, [center, radius, followUser, map]);
  return null;
}

function Recenter({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView(center, map.getZoom(), { animate: true });
  }, [center, map]);
  return null;
}

// Marcador de doação com popup + tooltip. Abre o popup quando a doação é selecionada na lista.
function OfferMarker({ offer, selected, onSelect, dark, routeIndex, now }) {
  const ref = useRef(null);
  useEffect(() => {
    if (selected && ref.current) ref.current.openPopup();
  }, [selected]);
  const meta = STATUS_META[offer.status] || STATUS_META.disponivel;
  const left = timeLeft(offer, now);
  return (
    <Marker
      ref={ref}
      position={[offer.latitude, offer.longitude]}
      icon={offerIcon(offer, dark, routeIndex, left.urgent && offer.status === "disponivel")}
      eventHandlers={{ click: () => onSelect(offer) }}
    >
      <Popup>
        <div className="space-y-1.5 min-w-[190px] text-slate-900">
          <div>
            <div className="text-[10px] uppercase tracking-wide text-slate-400">
              {categoryById(offer.category).label}
            </div>
            <div className="font-semibold text-sm leading-tight">{offer.item}</div>
          </div>
          <div className="text-xs text-slate-600">
            {offer.establishmentName} · {establishmentTypeLabel(offer.establishmentType)}
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Quantidade</span>
            <span>{formatKg(offer.quantityKg)}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Validade</span>
            <span className={left.urgent ? "text-rose-700 font-semibold" : ""}>{left.label}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Distância</span>
            <span>{formatDistance(offer.distance)}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Status</span>
            <span style={{ color: meta.markerLight }} className="font-medium">
              {meta.label}
            </span>
          </div>
          {offer.demo && <div className="pt-1 text-[11px] text-amber-700 font-medium">🧪 DEMO</div>}
        </div>
      </Popup>
      <Tooltip direction="top" offset={[0, -10]} opacity={1}>
        <div className="text-slate-900">
          <div className="font-medium text-xs">{offer.item}</div>
          <div className="text-[11px] text-slate-500">
            {formatKg(offer.quantityKg)} · {formatDistance(offer.distance)}
          </div>
        </div>
      </Tooltip>
    </Marker>
  );
}

export default function FoodMap({
  userPos,
  accuracy = null,
  followUser = true,
  onUserMove,
  offers = [],
  institutions = [],
  selected,
  onSelect,
  dark,
  radius = 2000,
  routePoints = [],
  routeOrder = {},
  now = Date.now(),
}) {
  const center = userPos || [-14.235, -51.9253];
  const sel = selected && selected.latitude != null ? [selected.latitude, selected.longitude] : null;
  return (
    <MapContainer center={center} zoom={userPos ? 15 : 4} className="w-full h-full min-w-0 min-h-0 z-0" zoomControl={false}>
      {/* OpenStreetMap: não exige chave de API. O tema escuro é feito por filtro CSS (ver index.css).
          `key` recria a camada quando o tema muda, para a classe ser reaplicada. */}
      <TileLayer
        key={dark ? "tiles-dark" : "tiles-light"}
        url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        className={dark ? "fz-tiles-dark" : ""}
        maxZoom={19}
      />
      <MapResizer />
      <FitSearchArea center={userPos} radius={radius} followUser={followUser} />
      <Recenter center={sel || center} />
      {userPos && (
        <>
          <Circle
            center={userPos}
            radius={radius}
            pathOptions={{ color: "#22c55e", weight: 1, fillColor: "#22c55e", fillOpacity: 0.06 }}
          />
          {/* Erro estimado da localização (só quando vem do GPS/aparelho). */}
          {accuracy != null && (
            <Circle
              center={userPos}
              radius={Math.max(accuracy, 1)}
              pathOptions={{ color: "#f59e0b", weight: 1, dashArray: "4 4", fillColor: "#f59e0b", fillOpacity: 0.07 }}
            />
          )}
          {/* Rota de coleta (linha reta entre as paradas, na ordem de proximidade). */}
          {routePoints.length >= 2 && (
            <Polyline positions={routePoints} pathOptions={{ color: "#f59e0b", weight: 3, dashArray: "6 6" }} />
          )}
          {/* Arraste o marcador para ajustar o local exato (útil em computadores sem GPS). */}
          <Marker
            position={userPos}
            icon={userIcon}
            draggable={!!onUserMove}
            zIndexOffset={1000}
            eventHandlers={{
              dragend: (e) => {
                const ll = e.target.getLatLng();
                if (onUserMove) onUserMove([ll.lat, ll.lng]);
              },
            }}
          >
            <Popup>
              Você está aqui 📍
              {onUserMove && (
                <>
                  <br />
                  <span style={{ fontSize: 11, opacity: 0.7 }}>Arraste o marcador para ajustar o local exato.</span>
                </>
              )}
            </Popup>
          </Marker>
        </>
      )}
      {institutions.map((inst) => (
        <Marker key={inst.id} position={[inst.latitude, inst.longitude]} icon={institutionIcon(dark)}>
          <Popup>
            <div className="space-y-1 min-w-[160px] text-slate-900">
              <div className="text-[10px] uppercase tracking-wide text-slate-400">{inst.type}</div>
              <div className="font-semibold text-sm">{inst.name}</div>
              <div className="pt-1 text-[11px] text-amber-700 font-medium">🧪 DEMO</div>
            </div>
          </Popup>
        </Marker>
      ))}
      {offers.map((o) => (
        <OfferMarker
          key={o.id}
          offer={o}
          selected={!!selected && selected.id === o.id}
          onSelect={onSelect}
          dark={dark}
          routeIndex={routeOrder[o.id]}
          now={now}
        />
      ))}
    </MapContainer>
  );
}
