import React, { useState } from "react";
import { X, Plus, MapPin } from "lucide-react";
import { CATEGORIES, ESTABLISHMENT_TYPES, toLocalInputValue } from "@/lib/food/offers";

const FIELD =
  "w-full mt-1 bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-sm text-nr-text placeholder-nr-dim/30 focus:outline-none focus:border-nr-accent transition";
const LABEL = "text-[11px] text-nr-dim/50 uppercase tracking-wide";

// Formulário de nova doação (perfil Estabelecimento). Publica no local atual do mapa.
export default function NewOfferModal({ open, defaultName, locationReady, onSubmit, onClose }) {
  const [form, setForm] = useState(() => ({
    establishmentName: defaultName || "",
    establishmentType: "supermercado",
    item: "",
    category: "hortifruti",
    quantityKg: "",
    validUntil: toLocalInputValue(Date.now() + 4 * 3600000),
    notes: "",
    fit: false,
  }));
  const [error, setError] = useState("");

  if (!open) return null;

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));

  const submit = () => {
    const res = onSubmit({ ...form, validUntil: new Date(form.validUntil).toISOString() });
    if (res && !res.ok) {
      setError(res.message);
      return;
    }
    setError("");
    setForm((f) => ({ ...f, item: "", quantityKg: "", notes: "", fit: false }));
  };

  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-[460px] max-w-[94vw] max-h-[92vh] overflow-y-auto rounded-2xl bg-nr-panel border border-nr-border shadow-2xl p-6 text-nr-text"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Plus className="w-4 h-4 text-nr-accent" /> Nova doação
          </h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/60 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={LABEL}>Estabelecimento</label>
              <input value={form.establishmentName} onChange={set("establishmentName")} className={FIELD} />
            </div>
            <div>
              <label className={LABEL}>Tipo</label>
              <select value={form.establishmentType} onChange={set("establishmentType")} className={FIELD}>
                {ESTABLISHMENT_TYPES.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className={LABEL}>Alimento</label>
            <input value={form.item} onChange={set("item")} placeholder="Ex.: Pães do dia, marmitas, frutas…" className={FIELD} />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={LABEL}>Categoria</label>
              <select value={form.category} onChange={set("category")} className={FIELD}>
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className={LABEL}>Quantidade (kg)</label>
              <input
                type="number"
                min="0"
                step="0.5"
                value={form.quantityKg}
                onChange={set("quantityKg")}
                placeholder="Ex.: 10"
                className={FIELD}
              />
            </div>
          </div>

          <div>
            <label className={LABEL}>Retirar até (validade)</label>
            <input type="datetime-local" value={form.validUntil} onChange={set("validUntil")} className={FIELD} />
          </div>

          <div>
            <label className={LABEL}>Observações (opcional)</label>
            <textarea
              rows={2}
              value={form.notes}
              onChange={set("notes")}
              placeholder="Ex.: retirar pela porta lateral, falar com o gerente…"
              className={`${FIELD} resize-none`}
            />
          </div>

          <label className="flex items-start gap-2.5 text-xs text-nr-dim/80 cursor-pointer">
            <input type="checkbox" checked={form.fit} onChange={set("fit")} className="w-4 h-4 mt-0.5 accent-nr-accent" />
            <span>
              Confirmo que o alimento está <strong>próprio para consumo</strong> (dentro da validade e bem conservado).
            </span>
          </label>

          <p className="flex items-start gap-2 text-[11px] text-nr-dim/50">
            <MapPin className="w-3.5 h-3.5 flex-shrink-0 mt-px" />
            {locationReady
              ? "A doação será publicada no ponto marcado no mapa (seu local atual). Arraste o marcador azul para ajustar."
              : "Ative a localização para publicar a doação no local certo."}
          </p>

          {error && <p className="text-xs text-rose-400">{error}</p>}
        </div>

        <div className="flex gap-2 mt-6">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-lg text-sm font-medium border border-nr-border text-nr-dim/80 hover:bg-nr-dim/10 transition"
          >
            Cancelar
          </button>
          <button
            onClick={submit}
            className="flex-1 py-2.5 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
          >
            Publicar doação
          </button>
        </div>
      </div>
    </div>
  );
}
