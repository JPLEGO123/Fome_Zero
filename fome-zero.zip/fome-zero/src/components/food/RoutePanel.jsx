import React from "react";
import { CheckCircle2, Route } from "lucide-react";
import { formatDistance, formatDuration, formatKg } from "@/lib/food/offers";

// Rota de coleta da instituição: doações reservadas, na ordem de proximidade (vizinho mais próximo).
// Distâncias em linha reta (estimativa), não por ruas.
export default function RoutePanel({ route, now, onSelect, onConfirm }) {
  const { stops, totalMeters, minutes } = route;
  return (
    <div className="rounded-xl bg-nr-panel p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-nr-dim/50">Rota de coleta</span>
        <Route className="w-4 h-4 text-nr-accent" />
      </div>

      {stops.length === 0 ? (
        <p className="text-[11px] text-nr-dim/50 leading-relaxed">
          Reserve doações para montar a rota de coleta, organizada por proximidade.
        </p>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-2.5">
            <div className="rounded-lg bg-nr-bg border border-nr-border p-2.5">
              <p className="text-[10px] uppercase tracking-wide text-nr-dim/40">Paradas</p>
              <p className="text-sm font-semibold mt-1">{stops.length}</p>
            </div>
            <div className="rounded-lg bg-nr-bg border border-nr-border p-2.5">
              <p className="text-[10px] uppercase tracking-wide text-nr-dim/40">Percurso</p>
              <p className="text-sm font-semibold mt-1">
                {formatDistance(totalMeters)} <span className="text-[10px] text-nr-dim/40">· ≈ {minutes} min</span>
              </p>
            </div>
          </div>

          <ol className="space-y-2">
            {stops.map(({ offer, legMeters }, i) => (
              <li key={offer.id} className="rounded-lg bg-nr-bg border border-nr-border p-2.5">
                <button onClick={() => onSelect(offer)} className="w-full text-left flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 text-[11px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-xs font-medium leading-snug">{offer.item}</span>
                    <span className="block text-[10px] text-nr-dim/50 truncate">
                      {offer.establishmentName} · {formatKg(offer.quantityKg)}
                    </span>
                    <span className="block text-[10px] text-nr-dim/50">
                      +{formatDistance(legMeters)} · reserva expira em{" "}
                      {formatDuration(new Date(offer.reservedUntil).getTime() - now)}
                    </span>
                  </span>
                </button>
                <button
                  onClick={() => onConfirm(offer)}
                  className="w-full mt-2 flex items-center justify-center gap-1.5 py-1.5 rounded-md text-[11px] font-medium bg-nr-btn/80 hover:bg-nr-btn text-white transition"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" /> Confirmar coleta
                </button>
              </li>
            ))}
          </ol>
        </>
      )}
    </div>
  );
}
