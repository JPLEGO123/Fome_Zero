// Nome do projeto na barra de título: "FOME" + "ZERO" (destaque na cor de acento).
export default function BrandName() {
  return (
    <span className="font-heading font-bold tracking-[0.18em] text-sm whitespace-nowrap select-none">
      <span className="text-nr-text">FOME </span>
      <span className="text-nr-accent">ZERO</span>
    </span>
  );
}
