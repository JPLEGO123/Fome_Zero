import React from "react";
import { X, Gauge, Tag, Sun, Moon, FlaskConical } from "lucide-react";

const fmtRadius = (m) => (m >= 1000 ? `${(m / 1000).toFixed(1).replace(".", ",")} km` : `${m} m`);

// Configurações do sistema: tema, raio de busca e filtro por nome.
// `showDemo`/`onToggleDemo` (opcionais) controlam a exibição das doações de demonstração.
export default function SystemMenu({ open, onClose, config, onChange, showDemo, onToggleDemo, onResetDemo }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-[420px] max-w-[92vw] max-h-[90vh] overflow-y-auto rounded-2xl bg-nr-panel border border-nr-border shadow-2xl p-6 text-nr-text"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-semibold flex items-center gap-2">
            <Gauge className="w-4 h-4 text-nr-accent" /> Sistema — Configurações
          </h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/60 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-5">
          {/* Tema */}
          <div>
            <label className="flex items-center gap-2 text-sm text-nr-dim/80 mb-2">
              <Sun className="w-4 h-4 text-nr-accent" /> Tema do aplicativo
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { id: "dark", label: "Escuro", Icon: Moon },
                { id: "light", label: "Claro", Icon: Sun },
              ].map(({ id, label, Icon }) => (
                <button
                  key={id}
                  onClick={() => onChange({ ...config, theme: id })}
                  className={`flex items-center justify-center gap-2 h-11 rounded-lg border text-sm font-medium transition ${
                    config.theme === id
                      ? "bg-nr-accent/15 border-nr-accent text-nr-accent"
                      : "bg-nr-bg border-nr-border text-nr-dim/70 hover:border-nr-dim/40"
                  }`}
                >
                  <Icon className="w-4 h-4" /> {label}
                </button>
              ))}
            </div>
          </div>

          {/* Raio de busca */}
          <div>
            <label className="flex items-center justify-between text-sm text-nr-dim/80 mb-2">
              <span className="flex items-center gap-2">
                <Gauge className="w-4 h-4 text-nr-accent" /> Raio de busca
              </span>
              <span className="text-nr-accent font-mono">{fmtRadius(config.radius)}</span>
            </label>
            <input
              type="range"
              min={200}
              max={5000}
              step={100}
              value={config.radius}
              onChange={(e) => onChange({ ...config, radius: Number(e.target.value) })}
              className="w-full accent-nr-accent"
            />
            <div className="flex justify-between text-[10px] text-nr-dim/30 mt-1">
              <span>200 m</span>
              <span>5 km</span>
            </div>
          </div>

          {/* Filtro por nome */}
          <div>
            <label className="flex items-center gap-2 text-sm text-nr-dim/80 mb-2">
              <Tag className="w-4 h-4 text-nr-accent" /> Filtrar por alimento ou estabelecimento
            </label>
            <input
              type="text"
              value={config.nameFilter}
              placeholder="Ex.: pães, hortifrúti, restaurante…"
              onChange={(e) => onChange({ ...config, nameFilter: e.target.value })}
              className="w-full bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-sm placeholder-nr-dim/30 focus:outline-none focus:border-nr-accent transition"
            />
          </div>

          {/* Demonstração */}
          {onToggleDemo && (
            <div className="rounded-xl border border-nr-border p-3 space-y-2.5">
              <label className="flex items-center justify-between gap-3 text-sm text-nr-dim/80 cursor-pointer">
                <span className="flex items-center gap-2">
                  <FlaskConical className="w-4 h-4 text-nr-demo" /> Mostrar dados de demonstração
                </span>
                <input
                  type="checkbox"
                  checked={!!showDemo}
                  onChange={(e) => onToggleDemo(e.target.checked)}
                  className="w-4 h-4 accent-nr-accent"
                />
              </label>
              <p className="text-[11px] text-nr-dim/50">
                São doações e instituições fictícias, geradas ao redor da sua localização, só para demonstrar o protótipo.
              </p>
              {onResetDemo && (
                <button
                  onClick={onResetDemo}
                  className="text-[11px] underline text-nr-accent hover:opacity-80"
                >
                  Restaurar a demonstração (limpa reservas e coletas de teste)
                </button>
              )}
            </div>
          )}
        </div>

        <button
          onClick={onClose}
          className="w-full mt-6 py-2.5 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
        >
          Salvar e aplicar
        </button>
      </div>
    </div>
  );
}
