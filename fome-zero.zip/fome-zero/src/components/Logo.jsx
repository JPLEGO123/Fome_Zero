// Símbolo do Fome Zero — espiga de trigo (símbolo da ODS 2) com gradiente verde→âmbar.
// O gradiente usa variáveis CSS de tema (--nr-grad-top / --nr-grad-bottom),
// adaptando-se automaticamente entre tema claro e escuro.
const GRAINS = [
  { cx: 17, cy: 17, rot: -38 },
  { cx: 31, cy: 17, rot: 38 },
  { cx: 17, cy: 26, rot: -38 },
  { cx: 31, cy: 26, rot: 38 },
  { cx: 17, cy: 35, rot: -38 },
  { cx: 31, cy: 35, rot: 38 },
];

export default function Logo({ className = "" }) {
  return (
    <svg
      viewBox="0 0 48 48"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="Fome Zero"
      preserveAspectRatio="xMidYMid meet"
    >
      <defs>
        <linearGradient id="fomeZeroGrad" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="48" y2="48">
          <stop offset="0%" stopColor="var(--nr-grad-top)" />
          <stop offset="100%" stopColor="var(--nr-grad-bottom)" />
        </linearGradient>
      </defs>
      <g fill="url(#fomeZeroGrad)">
        <ellipse cx="24" cy="9" rx="3.2" ry="5.2" />
        {GRAINS.map((g) => (
          <ellipse
            key={`${g.cx}-${g.cy}`}
            cx={g.cx}
            cy={g.cy}
            rx="3.2"
            ry="5.6"
            transform={`rotate(${g.rot} ${g.cx} ${g.cy})`}
          />
        ))}
        <rect x="23" y="16" width="2" height="28" rx="1" />
      </g>
    </svg>
  );
}
