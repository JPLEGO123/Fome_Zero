import { useCallback, useEffect, useRef, useState } from "react";

// Localização do usuário no Fome Zero — responsável APENAS pela geolocalização e pelos estados
// (desligada, localizando, ativa, erro). A plataforma funciona por proximidade geográfica: as
// doações são ordenadas e filtradas pela distância até este ponto.
//
// Precisão: o navegador costuma devolver primeiro uma posição aproximada (por IP/Wi-Fi) e,
// se houver GPS ou serviço de localização do sistema, melhora em seguida. Por isso usamos
// watchPosition por um tempo, ficamos sempre com a MELHOR leitura (menor erro, em metros) e
// expomos essa precisão. Em computadores sem GPS o erro pode ser grande: nesse caso o usuário
// pode arrastar o marcador no mapa para o local exato (posição manual).

export const RADAR_STATES = {
  OFF: "off",
  LOCATING: "locating",
  ACTIVE: "active",
  ERROR: "error",
};

const GOOD_ACCURACY_M = 20; // para de refinar quando o erro estimado for menor que isso
const MAX_REFINE_MS = 45000; // tempo máximo refinando a posição

export function useRadar() {
  const [state, setState] = useState(RADAR_STATES.OFF);
  const [userPos, setUserPos] = useState(null);
  const [accuracy, setAccuracy] = useState(null); // metros; null = desconhecida/manual
  const [source, setSource] = useState("gps"); // "gps" | "manual"
  const [refining, setRefining] = useState(false);
  const [error, setError] = useState("");

  const watchIdRef = useRef(null);
  const timerRef = useRef(null);
  const bestRef = useRef(Infinity); // melhor precisão (menor erro) já recebida

  const stopWatch = useCallback(() => {
    if (watchIdRef.current != null) {
      navigator.geolocation?.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    setRefining(false);
  }, []);

  // Libera o GPS ao sair da página.
  useEffect(() => stopWatch, [stopWatch]);

  // Inicia (ou reinicia) a busca da melhor localização do dispositivo.
  const refreshLocation = useCallback(() => {
    setError("");
    if (!navigator.geolocation) {
      setError("Geolocalização não suportada neste navegador.");
      setState(RADAR_STATES.ERROR);
      return;
    }
    stopWatch();
    bestRef.current = Infinity;
    setSource("gps");
    setRefining(true);
    // Se já existe uma posição na tela, mantém o radar ativo enquanto refina.
    setState((prev) => (prev === RADAR_STATES.ACTIVE ? prev : RADAR_STATES.LOCATING));

    const onFix = (pos) => {
      const { latitude, longitude, accuracy: acc } = pos.coords;
      const err = typeof acc === "number" ? acc : Infinity;
      // Só aceita leituras melhores que a atual (evita o ponto "pular" para uma estimativa pior).
      if (err < bestRef.current || bestRef.current === Infinity) {
        bestRef.current = err;
        setUserPos([latitude, longitude]);
        setAccuracy(Number.isFinite(err) ? err : null);
        setState(RADAR_STATES.ACTIVE);
      }
      if (err <= GOOD_ACCURACY_M) stopWatch();
    };

    const onError = (err) => {
      if (err.code === err.PERMISSION_DENIED) {
        stopWatch();
        setError(
          "Localização negada. Autorize o acesso à localização nas permissões do navegador para usar o radar."
        );
        setState(RADAR_STATES.ERROR);
        return;
      }
      // Timeout/indisponível: só é erro se ainda não temos nenhuma posição.
      if (bestRef.current === Infinity) {
        stopWatch();
        setError(
          "Não foi possível obter sua localização. Verifique se o GPS/localização do dispositivo está ativado."
        );
        setState(RADAR_STATES.ERROR);
      }
    };

    watchIdRef.current = navigator.geolocation.watchPosition(onFix, onError, {
      enableHighAccuracy: true,
      maximumAge: 0,
      timeout: 20000,
    });
    timerRef.current = setTimeout(stopWatch, MAX_REFINE_MS);
  }, [stopWatch]);

  const togglePower = useCallback(() => {
    // Se ativo ou localizando, desliga o radar.
    if (state === RADAR_STATES.ACTIVE || state === RADAR_STATES.LOCATING) {
      stopWatch();
      setState(RADAR_STATES.OFF);
      return;
    }
    // Caso contrário (off ou error), (re)inicia pedindo a geolocalização.
    refreshLocation();
  }, [state, stopWatch, refreshLocation]);

  // Posição ajustada manualmente (arrastando o marcador no mapa): vale mais que a estimativa do aparelho.
  const setManualPos = useCallback(
    (pos) => {
      stopWatch();
      setUserPos([pos[0], pos[1]]);
      setAccuracy(null);
      setSource("manual");
      setState(RADAR_STATES.ACTIVE);
    },
    [stopWatch]
  );

  return { state, userPos, accuracy, source, refining, error, togglePower, refreshLocation, setManualPos };
}
