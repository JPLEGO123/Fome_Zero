import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ROLES,
  STATUS,
  buildDemoInstitutions,
  buildDemoOffers,
  makeEvent,
  reservationCode,
  reservationDeadline,
  resolveOffer,
} from "@/lib/food/offers";

// Estado do Fome Zero no navegador (protótipo, sem servidor):
// - perfil de uso (instituição ou estabelecimento);
// - doações criadas pelo usuário (reais neste navegador);
// - estado das doações de DEMONSTRAÇÃO (reservas/coletas feitas sobre elas);
// - histórico de eventos (alimenta a página Histórico e o impacto).
// Tudo é salvo em localStorage; nada é enviado a nenhum servidor.

const KEYS = {
  profile: "fomezero:profile",
  offers: "fomezero:offers",
  demo: "fomezero:demo_state",
  events: "fomezero:events",
  showDemo: "fomezero:show_demo",
};
const EVENT_LIMIT = 500;

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw == null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* armazenamento indisponível: mantém só em memória */
  }
}

const uid = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

const DEFAULT_PROFILE = {
  id: null,
  role: ROLES.INSTITUICAO,
  names: { instituicao: "Minha Instituição", estabelecimento: "Meu Estabelecimento" },
};

// Campos limpos quando uma reserva é cancelada (a doação volta a ficar disponível).
const RELEASE_PATCH = {
  status: STATUS.DISPONIVEL,
  reservedBy: null,
  reservedById: null,
  reservedAt: null,
  reservedUntil: null,
  reservationCode: null,
};

const ok = (message, data) => ({ ok: true, message, data });
const fail = (message) => ({ ok: false, message });

function loadProfile() {
  const saved = read(KEYS.profile, null);
  const profile = {
    ...DEFAULT_PROFILE,
    ...(saved || {}),
    names: { ...DEFAULT_PROFILE.names, ...((saved && saved.names) || {}) },
  };
  if (!profile.id) profile.id = uid("user");
  return profile;
}

// Histórico de eventos isolado (usado pela página Histórico, que não precisa do resto do estado).
export function useFoodEvents() {
  const [events, setEvents] = useState(() => read(KEYS.events, []));
  const clear = useCallback(() => {
    setEvents([]);
    write(KEYS.events, []);
  }, []);
  return { events, clear };
}

export function useFoodBank({ userPos }) {
  const [profile, setProfile] = useState(loadProfile);
  const [ownOffers, setOwnOffers] = useState(() => read(KEYS.offers, []));
  const [demoState, setDemoState] = useState(() => read(KEYS.demo, {}));
  const [events, setEvents] = useState(() => read(KEYS.events, []));
  const [showDemo, setShowDemo] = useState(() => read(KEYS.showDemo, true));
  const [now, setNow] = useState(() => Date.now());
  const loadTimeRef = useRef(Date.now());

  useEffect(() => write(KEYS.profile, profile), [profile]);
  useEffect(() => write(KEYS.offers, ownOffers), [ownOffers]);
  useEffect(() => write(KEYS.demo, demoState), [demoState]);
  useEffect(() => write(KEYS.events, events), [events]);
  useEffect(() => write(KEYS.showDemo, showDemo), [showDemo]);

  // Relógio: reavalia validades e reservas a cada 30 s (RN02 e RN04).
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(t);
  }, []);

  // Âncora das doações de demonstração, arredondada (~100 m) para não "pular" enquanto a posição refina.
  const anchor = useMemo(
    () => (userPos ? [Math.round(userPos[0] * 1000) / 1000, Math.round(userPos[1] * 1000) / 1000] : null),
    [userPos]
  );

  const demoOffers = useMemo(() => {
    if (!showDemo || !anchor) return [];
    return buildDemoOffers(anchor, loadTimeRef.current).map((o) => ({ ...o, ...(demoState[o.id] || {}) }));
  }, [showDemo, anchor, demoState]);

  const institutions = useMemo(() => (showDemo && anchor ? buildDemoInstitutions(anchor) : []), [showDemo, anchor]);

  const offers = useMemo(
    () => [...ownOffers, ...demoOffers].map((o) => resolveOffer(o, now)),
    [ownOffers, demoOffers, now]
  );

  const currentName = profile.names[profile.role] || "";

  // ---------- Perfil ----------
  const setRole = useCallback((role) => setProfile((p) => ({ ...p, role })), []);
  const setName = useCallback(
    (name) => setProfile((p) => ({ ...p, names: { ...p.names, [p.role]: name } })),
    []
  );

  // ---------- Utilidades internas ----------
  const patchOffer = useCallback((offer, patch) => {
    if (offer.demo) {
      setDemoState((s) => ({ ...s, [offer.id]: { ...(s[offer.id] || {}), ...patch } }));
    } else {
      setOwnOffers((list) => list.map((o) => (o.id === offer.id ? { ...o, ...patch } : o)));
    }
  }, []);

  const log = useCallback((type, offer, extra) => {
    setEvents((list) => [makeEvent(type, offer, extra), ...list].slice(0, EVENT_LIMIT));
  }, []);

  const find = useCallback((id) => offers.find((o) => o.id === id), [offers]);

  // ---------- Ações (cada uma valida as regras de negócio) ----------

  // Estabelecimento publica uma doação no local atual.
  const publish = useCallback(
    (data, pos) => {
      if (profile.role !== ROLES.ESTABELECIMENTO) {
        return fail("Apenas estabelecimentos publicam doações. Troque o perfil para Estabelecimento.");
      }
      if (!pos) return fail("Ative a localização para publicar a doação no local certo.");
      const item = (data.item || "").trim();
      const kg = Number(data.quantityKg);
      const validMs = new Date(data.validUntil).getTime();
      if (!item) return fail("Informe qual alimento será doado.");
      if (!Number.isFinite(kg) || kg <= 0) return fail("Informe uma quantidade maior que zero.");
      if (!Number.isFinite(validMs) || validMs <= Date.now()) return fail("A validade precisa estar no futuro.");
      if (!data.fit) return fail("Confirme que o alimento está próprio para consumo.");

      const offer = {
        id: uid("offer"),
        demo: false,
        establishmentName: (data.establishmentName || currentName || "Meu Estabelecimento").trim(),
        establishmentType: data.establishmentType,
        item,
        category: data.category,
        quantityKg: kg,
        notes: (data.notes || "").trim(),
        latitude: pos[0],
        longitude: pos[1],
        createdAt: new Date().toISOString(),
        validUntil: new Date(validMs).toISOString(),
        status: STATUS.DISPONIVEL,
        reservedBy: null,
        reservedById: null,
        reservedAt: null,
        reservedUntil: null,
        reservationCode: null,
      };
      setOwnOffers((list) => [offer, ...list]);
      log("publicada", offer);
      return ok("Doação publicada! Instituições próximas já podem reservá-la.", offer);
    },
    [profile.role, currentName, log]
  );

  // Instituição reserva uma doação disponível (RN03: reserva exclusiva; RN04: por até 2 h).
  const reserve = useCallback(
    (id) => {
      if (profile.role !== ROLES.INSTITUICAO) return fail("Apenas instituições reservam doações. Troque o perfil para Instituição.");
      if (!currentName.trim()) return fail("Informe o nome da instituição no perfil.");
      const offer = find(id);
      if (!offer) return fail("Doação não encontrada.");
      if (offer.status !== STATUS.DISPONIVEL) return fail("Esta doação não está mais disponível.");
      const t = Date.now();
      const patch = {
        status: STATUS.RESERVADA,
        reservedBy: currentName.trim(),
        reservedById: profile.id,
        reservedAt: new Date(t).toISOString(),
        reservedUntil: reservationDeadline(offer, t),
        reservationCode: reservationCode(),
      };
      patchOffer(offer, patch);
      log("reservada", { ...offer, ...patch });
      return ok(`Reservada! Código ${patch.reservationCode}. Retire em até 2 h.`, patch);
    },
    [profile.role, profile.id, currentName, find, patchOffer, log]
  );

  const cancelReservation = useCallback(
    (id) => {
      const offer = find(id);
      if (!offer || offer.status !== STATUS.RESERVADA) return fail("Não há reserva ativa para cancelar.");
      if (offer.reservedById !== profile.id) return fail("Só a instituição que reservou pode cancelar a reserva.");
      patchOffer(offer, RELEASE_PATCH);
      log("reserva_cancelada", offer);
      return ok("Reserva cancelada. A doação voltou a ficar disponível.");
    },
    [profile.id, find, patchOffer, log]
  );

  const confirmCollection = useCallback(
    (id) => {
      const offer = find(id);
      if (!offer || offer.status !== STATUS.RESERVADA) return fail("Só é possível confirmar a coleta de uma doação reservada.");
      if (offer.reservedById !== profile.id) return fail("Só a instituição que reservou pode confirmar a coleta.");
      const patch = { status: STATUS.COLETADA, collectedAt: new Date().toISOString() };
      patchOffer(offer, patch);
      log("coletada", { ...offer, ...patch });
      return ok("Coleta confirmada! O impacto foi registrado no Histórico.");
    },
    [profile.id, find, patchOffer, log]
  );

  // Estabelecimento retira do ar uma doação própria que ainda não foi reservada.
  const cancelOffer = useCallback(
    (id) => {
      const offer = find(id);
      if (!offer || offer.demo) return fail("Só é possível cancelar doações criadas por você.");
      if (offer.status !== STATUS.DISPONIVEL) return fail("Só é possível cancelar uma doação que ainda está disponível.");
      patchOffer(offer, { status: STATUS.CANCELADA });
      log("cancelada", offer);
      return ok("Doação cancelada.");
    },
    [find, patchOffer, log]
  );

  const resetDemo = useCallback(() => {
    setDemoState({});
    setEvents((list) => list.filter((e) => !e.demo));
  }, []);

  return {
    profile,
    currentName,
    offers,
    institutions,
    events,
    showDemo,
    now,
    setRole,
    setName,
    setShowDemo,
    publish,
    reserve,
    cancelReservation,
    confirmCollection,
    cancelOffer,
    resetDemo,
  };
}
