# Fome Zero — Plataforma de Gestão e Doação de Alimentos Comunitários

Protótipo web (responsivo, também usável no celular) que conecta **estabelecimentos** (supermercados, hortifrútis e
restaurantes) com excedentes de alimentos a **instituições** (abrigos, cozinhas solidárias e instituições beneficentes),
por **proximidade geográfica**. Alinhado à **ODS 2 — Fome Zero e Agricultura Sustentável** (metas 2.1 e 12.3).

## Como rodar

```bash
npm install
npm run dev
```

Abra `http://localhost:5173` e clique em **Ativar localização**.

## O que o protótipo faz

- Mapa (OpenStreetMap) com as doações próximas, raio de busca ajustável e localização com precisão exibida.
- **Estabelecimento:** publica doações (alimento, categoria, quantidade, validade).
- **Instituição:** reserva doações (reserva exclusiva por até 2 h), monta a **rota de coleta** por proximidade e confirma a coleta.
- Perecíveis com pouca validade são marcados como **urgentes**; a lista ordena por proximidade ou urgência.
- **Histórico** com impacto acumulado (kg resgatados, refeições estimadas) e gráfico por dia.

## Regras de negócio implementadas

RN01 alimento próprio para consumo · RN02 expiração automática · RN03 reserva exclusiva ·
RN04 reserva de até 2 h · RN05 urgência de perecíveis · RN06 perfis (estabelecimento publica, instituição reserva).

## Sobre os dados

Doações e instituições marcadas com **DEMO** são fictícias (geradas ao redor da sua localização). Tudo é salvo apenas
no navegador (`localStorage`); não há servidor. Em uma versão completa, um banco de dados compartilhado permitiria a
troca de informações entre estabelecimentos e instituições reais.

## Estrutura

- `src/lib/food/offers.js` — regras de negócio (puras): validade, reserva, proximidade, rota, impacto.
- `src/hooks/useFoodBank.js` — estado e ações (publicar, reservar, cancelar, confirmar coleta) com persistência local.
- `src/hooks/useRadar.js` — geolocalização com refinamento de precisão e ajuste manual do marcador.
- `src/components/food/` — mapa, lista, detalhes, formulário, perfil, rota e impacto.
- `src/pages/` — Home (mapa), Histórico e Sobre.
